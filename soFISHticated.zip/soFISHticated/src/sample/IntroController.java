package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class IntroController {

    @FXML Button playBut;
    @FXML Button rulesBut;
    
    @FXML private void handlePlayButtonAction(ActionEvent event) throws IOException {
        Parent myParent = FXMLLoader.load(getClass().getResource("GameController.fxml"));
        Scene mapScene = new Scene(myParent);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(mapScene);
        appStage.show();
    }
    @FXML private void handleRulesButtonAction(ActionEvent event) throws IOException {
        Parent myParent = FXMLLoader.load(getClass().getResource("Rules.fxml"));
        Scene mapScene = new Scene(myParent);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(mapScene);
        appStage.show();
    }
    
}
