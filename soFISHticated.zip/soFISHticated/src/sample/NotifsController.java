package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class NotifsController {

    private static long start = System.currentTimeMillis();
    private static long finish = start+10000;

    @FXML Label label;

    //set label to game state
    @FXML public void initialize(){
        label.setText("gamestatehere");
        //TODO: get game state
    }

    public static void main (String[]args) {
        if (System.currentTimeMillis() == finish) {
            ActionEvent event = new ActionEvent();
            ((Stage) (((Button) event.getSource()).getScene().getWindow())).close();
        }
    }

}
