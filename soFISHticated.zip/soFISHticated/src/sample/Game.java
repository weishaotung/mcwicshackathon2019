package sample;

import java.io.*;
import java.net.*;
public class Game {
	
	//attributes
	private Player[] players;
	
	//constructor
	public Game() {
		
	}
	
	
	
	private ClientSideConnection csc;
	
	
	public void connectToServer() {
		csc = new ClientSideConnection();
	}
	
	//Client connection 
	private class ClientSideConnection {
		
		private Socket socket;
		private DataInputStream dataIn;
		private DataOutputStream dataOut;
		
		public ClientSideConnection() {
			System.out.println("---Client---");
			try {
				socket = new Socket("localhost", 51734);
				dataIn = new DataInputStream(socket.getInputStream());
				dataOut = new DataOutputStream(socket.getOutputStream());
				
			} catch(IOException e) {
				System.out.println("IO Exception from CSC constructor");
			}
		}
	}
	
	public static void main(String[] args) {

	    /*
	    player = 1;
	    while(both team's win # < 5) {
            for player:
                Parent myParent = FXMLLoader.load(getClass().getResource("Ask.fxml"));
                Scene mapScene = new Scene(myParent);
                Stage appStage = new Stage();
                appStage.setScene(mapScene);
                appStage.show();
	    }
	     */

	}
}
