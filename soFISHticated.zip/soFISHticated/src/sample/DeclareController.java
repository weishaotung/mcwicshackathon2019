package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Created by akang on 09/02/2019.
 */
public class DeclareController {
    @FXML Button declareBut;
    @FXML ChoiceBox setChoice;
    @FXML Text player1Txt;
    @FXML Text player2Txt;
    @FXML Text player3Txt;
    @FXML ListView player1Options;
    @FXML ListView player2Options;
    @FXML ListView player3Options;
    
    @FXML private void handleDeclareButtonAction(ActionEvent event) throws IOException {
        ////FROM SERVER
        //get values for deck
        //get values for player 1
        //get values for player 2
        //get values for player 3
        //check values with player hands
        /*
        if (matches) {
            put declared set into correct team's wins
            check num of wins if less than 5 then
            prompt for user's next turn
        } else {
            return saying that they declared wrong in a notification
            give declared set into other team's wins
            check num of wins if less than 5 then
            prompt for user's next turn
        }
         */
        //change window to game window
        Parent myParent = FXMLLoader.load(getClass().getResource("Game.fxml"));
        Scene mapScene = new Scene(myParent);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(mapScene);
        appStage.show();
    }
    
}
