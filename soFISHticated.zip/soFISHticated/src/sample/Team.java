package sample;

public class Team {
	
	//attributes
	private Player[] players;
	private int decksDeclared;
	
	//constructor
	public Team (Player[] players, int decksDeclared) {
		this.players = players;
		this.decksDeclared = decksDeclared;
	}
	
	public Player[] getPlayers() {
		return this.players;
	}
	
	public int decksDeclared () {
		return this.decksDeclared;
	}

}