package sample;

public class GameServer {

}
