package sample;

import java.util.ArrayList;

public class Player {
	//attributes
	private String name;
	private ArrayList<Card> hand;

	//constructors
	public Player (String name) {
		this.name = name;
	}
	
	//getter/setter methods
	public String getName() {
		return this.name;
	}
	
	public ArrayList<Card> getHand() {
		return this.hand;
	}
	
	public void setHand (ArrayList<Card> hand) {
		this.hand=hand;
	}
	
	public void displayHand () {
		for (int i=0; i<hand.size(); i++) {
			System.out.println(hand.get(i));
		}
	}
}