package sample;

import sample.Card;

import java.util.ArrayList;
public class Deck {
	
	private Card[] deck;
	
	public Deck() {
		deck = new Card[54];
		int counter = 0;
		for(int i=0; i<4;i++) {
			for(int j=1; j<14; j++) {
				deck[counter] = new Card(i,j);
				counter++;
			}
		}
		deck[52] = new Card(Card.JOKER,1);
		deck[53] = new Card(Card.JOKER,2);
	}
	
	public void shuffle() {
		for(int i=deck.length-1; i>0; i--) {
			int randomNumber = (int)(Math.random()*(i+1));
			Card temp = deck[i];
			deck[i] = deck[randomNumber];
			deck[randomNumber] = temp;
		}
	}
	
	public String toString() {
		String s = "";
		for(int i=0; i<deck.length; i++) {
			s += deck[i];
			s += "\n";
		}
		return s;
	}
	
	/*method to deal the cards to each player
	there will be 6 players 
	need to deal 9 cards to each player 
	sol1) divide deck by 6 and store the cards in each player's hand
	array of players? 
	sol2) give one card to each player until they all have 9
	***change Team s and s.getPlayers()
	*/
	public void dealCard(Team s) {
		int counter=0;
		for(int i=0; i<6; i++) {
			ArrayList<Card> temp = new ArrayList<Card>();
			for(int j=0; j<9; j++) {
				temp.add(deck[j+counter]);	
				counter+=9;
			}
			s.getPlayers()[i].setHand(temp);
		}
	}
		
	public static void main(String[] args) {
		Deck deck1 = new Deck();
		deck1.shuffle();
		System.out.println(deck1);
	}
}
