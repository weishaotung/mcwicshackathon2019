package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.stage.Stage;

public class AskController {

    @FXML Button okButton;
    @FXML ChoiceBox playerSelect;
    @FXML ChoiceBox deckSelect;
    @FXML ChoiceBox cardSelect;

    @FXML private void handleOKButtonAction(ActionEvent event) {
        ((Stage)(((Button)event.getSource()).getScene().getWindow())).close();
    }
}
